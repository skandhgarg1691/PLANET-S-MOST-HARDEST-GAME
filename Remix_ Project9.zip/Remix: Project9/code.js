var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["bf64981d-d9fa-42a6-8f8d-407bb51380f6","b5cdc706-21d1-4b21-9efe-6347d2f0f96b"],"propsByKey":{"bf64981d-d9fa-42a6-8f8d-407bb51380f6":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"Vwqs.xDLwejV6Detq86GPSRsSEwC8pxr","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/bf64981d-d9fa-42a6-8f8d-407bb51380f6.png"},"b5cdc706-21d1-4b21-9efe-6347d2f0f96b":{"name":"kidportrait_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy/category_faces/kidportrait_05.png","frameSize":{"x":314,"y":363},"frameCount":1,"looping":true,"frameDelay":2,"version":"03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":314,"y":363},"rootRelativePath":"assets/api/v1/animation-library/gamelab/03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy/category_faces/kidportrait_05.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;
var gamestate="serve";
var parking=createSprite(10,195,50,150)
parking.shapeColor="lightblue"
var opticals=createSprite(350,195,50,150)
 opticals.shapeColor="yellow"
  boundary1 = createSprite(190,120,420,5);
  boundary1.shapeColor="black"
  boundary2 = createSprite(190,270,420,5);
  boundary2.shapeColor="black"
  sam = createSprite(20,200,13,13);
  sam.setAnimation("kidportrait_05_1")
  sam.scale=0.08
  sam.shapeColor = "green";
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
  
 


function draw() {
   background("grey");
  fill("black")
  textFont("Hello World")
  textSize(30)
  text("Lives: " + life,200,50);
  strokeWeight(0);
 

if (gamestate==="serve") {
  textFont("Hello World")
  fill("white")
  textSize(20)
  text("Welcome!Press Enter to start",60,300)
  
  fill("blue")
  textSize(15)
  text("Rules-1.Press right or left to move ",10,340)
  
   fill("blue")
  textSize(15)
  text("2.Reach Opticals within 5 lifes",10,360)
  
   fill("blue")
  textSize(15)
  text("3. Don't touch the cars",10,380)
  
if (keyDown(ENTER)) {
    gamestate="play"
 }
  
}
if (gamestate==="play") {
 //add the velocity to make the car move.
if (keyDown(ENTER)) {
  car1.velocityY=5
car2.velocityY=5
car3.velocityY=-5
car4.velocityY=-5
}

//Add the condition to make the sam move left and right
if (keyDown("right")) {
  sam.x=sam.x+2
}
if (keyDown("left")) {
  sam.x=sam.x-2
}
  // create bounceoff function to make the car bounceoff the boundaries
car1.bounceOff(boundary1)
car1.bounceOff(boundary2)
car2.bounceOff(boundary1)
car2.bounceOff(boundary2)
car3.bounceOff(boundary2)
car3.bounceOff(boundary1)
car4.bounceOff(boundary1)
car4.bounceOff(boundary2)
if (life==5) {
  gamestate="end"}
if (sam.isTouching(car1)||(sam.isTouching(car2)||(sam.isTouching(car3)
||(sam.isTouching(car4))))) {
 playSound("assets/category_achievements/lighthearted_bonus_objective_1.mp3",false) 
}



}

if (gamestate==="end") {
  textFont("Hello World")
  textSize(25)
  fill("black")
  text("Game Over!",180,350)
  car1.velocityY=0
  car2.velocityY=0
  car3.velocityY=0
  car4.velocityY=0



}

if (life===4) {
  textFont("Hello World")
  fill("black")
  textSize(20)
  text("One life left!",180,350)
}
textFont("Hello World")
textSize(20)
fill("pink")
text("Opticals",320,105)


textFont("Hello World")
textSize(20)
fill("pink")
text("You",11,110)







//Add the condition to reduce the life of sam if it touches the car.
 if(
     sam.isTouching(car1)||
     sam.isTouching(car2)||
     sam.isTouching(car3)||
     sam.isTouching(car4))
  {
     sam.x = 20;
     sam.y = 190;
     life = life + 1;
  }
  
  


 drawSprites();
 createEdgeSprites()
 sam.bounceOff(edges)
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
